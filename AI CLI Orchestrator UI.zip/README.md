
  # AI CLI Orchestrator UI

  This is a code bundle for AI CLI Orchestrator UI. The original project is available at https://www.figma.com/design/Pj9yV0igBQdNSu5YAhr0Oi/AI-CLI-Orchestrator-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  