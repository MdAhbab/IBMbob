import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Status = "online" | "offline" | "limited";
export type AuthMethod = "api_key" | "oauth" | "ssh" | "bearer" | "account";

export type Provider = {
  id: string;
  name: string;
  glyph: string;
  color: string;
  description: string;
  status: Status;
  enabled: boolean;
  configured: boolean;
  authMethod: AuthMethod;
  authMethods: AuthMethod[];
  model: string;
  models: string[];
  endpoint?: string;
  dailyCap: number;
  /** Email associated with an `account` or `oauth` login (e.g. ChatGPT plan email). */
  accountEmail?: string;
  /** Provider name shown when collecting an account email ("ChatGPT", "Google", "GitHub"...). */
  accountProvider?: string;
  /** Plan label resolved from the account email (e.g. "ChatGPT Plus"). */
  accountPlan?: string;
};

export const DEFAULT_PROVIDERS: Provider[] = [
  {
    id: "claude",
    name: "Claude Code",
    glyph: "✻",
    color: "text-amber-500",
    description: "Anthropic's flagship coding agent — best for complex logic, refactors, long context.",
    status: "online",
    enabled: true,
    configured: false,
    authMethod: "account",
    authMethods: ["account", "api_key", "ssh"],
    accountProvider: "Anthropic",
    model: "claude-sonnet-4-6",
    models: ["claude-opus-4-7", "claude-sonnet-4-6", "claude-haiku-4-5"],
    dailyCap: 20,
  },
  {
    id: "gemini",
    name: "Gemini CLI",
    glyph: "✦",
    color: "text-indigo-500",
    description: "Google's Gemini — strong on multimodal, UI generation, large context windows.",
    status: "online",
    enabled: true,
    configured: false,
    authMethod: "account",
    authMethods: ["account", "api_key"],
    accountProvider: "Google",
    model: "gemini-3-pro",
    models: ["gemini-3-pro", "gemini-3-flash", "gemini-2.5-pro"],
    dailyCap: 15,
  },
  {
    id: "codex",
    name: "Codex CLI",
    glyph: "◆",
    color: "text-emerald-500",
    description: "OpenAI Codex — excels at backend, schemas, migrations, and CLI scripting.",
    status: "online",
    enabled: true,
    configured: false,
    authMethod: "account",
    authMethods: ["account", "api_key", "bearer"],
    accountProvider: "ChatGPT",
    model: "gpt-codex-mini",
    models: ["gpt-codex", "gpt-codex-mini", "o4-mini"],
    dailyCap: 10,
  },
  {
    id: "copilot",
    name: "Copilot CLI",
    glyph: "❍",
    color: "text-zinc-500 dark:text-zinc-300",
    description: "GitHub Copilot — fast inline completions and tests, tight GH integration.",
    status: "online",
    enabled: true,
    configured: false,
    authMethod: "account",
    authMethods: ["account", "ssh"],
    accountProvider: "GitHub",
    model: "copilot-chat",
    models: ["copilot-chat", "copilot-claude", "copilot-gpt5"],
    dailyCap: 12,
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    glyph: "▲",
    color: "text-violet-500",
    description: "DeepSeek-Coder — strong on perf profiling and lower-level optimisation.",
    status: "limited",
    enabled: true,
    configured: false,
    authMethod: "api_key",
    authMethods: ["api_key", "bearer"],
    model: "deepseek-coder-v3",
    models: ["deepseek-coder-v3", "deepseek-chat-v3", "deepseek-r1"],
    dailyCap: 10,
  },
  {
    id: "kimi",
    name: "Kimi Code",
    glyph: "✺",
    color: "text-rose-500",
    description: "Moonshot's Kimi — long-context translations and documentation work.",
    status: "online",
    enabled: false,
    configured: false,
    authMethod: "api_key",
    authMethods: ["api_key", "bearer"],
    model: "kimi-k2",
    models: ["kimi-k2", "kimi-k1.5"],
    dailyCap: 8,
  },
  {
    id: "cline",
    name: "Cline CLI",
    glyph: "◈",
    color: "text-cyan-500",
    description: "Cline — autonomous repo watcher; great at change-driven jobs.",
    status: "online",
    enabled: false,
    configured: false,
    authMethod: "account",
    authMethods: ["account", "api_key", "ssh"],
    accountProvider: "Google",
    model: "cline-claude",
    models: ["cline-default", "cline-claude", "cline-gpt5"],
    dailyCap: 10,
  },
  {
    id: "bob",
    name: "IBM BOB",
    glyph: "∎",
    color: "text-blue-500",
    description: "IBM BOB on Granite — enterprise-friendly code completion via SSH.",
    status: "online",
    enabled: true,
    configured: false,
    authMethod: "ssh",
    authMethods: ["ssh", "bearer"],
    model: "granite-3.2-code",
    models: ["granite-3.2-code", "granite-3.1-code-base"],
    endpoint: "bob.ibmcloud.com:22",
    dailyCap: 15,
  },
];

export type Workspace = { path: string; name: string };

export type OrchestratorCfg = {
  model: string;
  routingStrategy: "specialty" | "round_robin" | "cheapest" | "fastest";
  parallelism: number;
  autoFailover: boolean;
  globalDailyCap: number;
};

type AppState = {
  onboarded: boolean;
  workspace: Workspace | null;
  providers: Provider[];
  orchestrator: OrchestratorCfg;
  prefs: { sound: boolean; desktopNotifs: boolean; autoSync: boolean; fontSize: "sm" | "md" | "lg" };
};

type Ctx = AppState & {
  setOnboarded: (v: boolean) => void;
  setWorkspace: (w: Workspace | null) => void;
  setProviders: React.Dispatch<React.SetStateAction<Provider[]>>;
  setOrchestrator: React.Dispatch<React.SetStateAction<OrchestratorCfg>>;
  setPrefs: React.Dispatch<React.SetStateAction<AppState["prefs"]>>;
  reset: () => void;
};

const StoreCtx = createContext<Ctx | null>(null);

const KEY = "orch.state.v3";

const DEFAULT_STATE: AppState = {
  onboarded: false,
  workspace: null,
  providers: DEFAULT_PROVIDERS,
  orchestrator: {
    model: "granite-3.2-instruct",
    routingStrategy: "specialty",
    parallelism: 4,
    autoFailover: true,
    globalDailyCap: 80,
  },
  prefs: { sound: true, desktopNotifs: false, autoSync: true, fontSize: "md" },
};

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => {
    if (typeof window === "undefined") return DEFAULT_STATE;
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return DEFAULT_STATE;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return DEFAULT_STATE;
      return {
        ...DEFAULT_STATE,
        ...parsed,
        providers:
          Array.isArray(parsed.providers) && parsed.providers.length
            ? parsed.providers
            : DEFAULT_PROVIDERS,
        orchestrator: { ...DEFAULT_STATE.orchestrator, ...(parsed.orchestrator || {}) },
        prefs: { ...DEFAULT_STATE.prefs, ...(parsed.prefs || {}) },
      };
    } catch {
      return DEFAULT_STATE;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {}
  }, [state]);

  return (
    <StoreCtx.Provider
      value={{
        ...state,
        setOnboarded: (v) => setState((s) => ({ ...s, onboarded: v })),
        setWorkspace: (w) => setState((s) => ({ ...s, workspace: w })),
        setProviders: (u) =>
          setState((s) => ({
            ...s,
            providers: typeof u === "function" ? (u as any)(s.providers) : u,
          })),
        setOrchestrator: (u) =>
          setState((s) => ({
            ...s,
            orchestrator: typeof u === "function" ? (u as any)(s.orchestrator) : u,
          })),
        setPrefs: (u) =>
          setState((s) => ({
            ...s,
            prefs: typeof u === "function" ? (u as any)(s.prefs) : u,
          })),
        reset: () => setState(DEFAULT_STATE),
      }}
    >
      {children}
    </StoreCtx.Provider>
  );
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("StoreCtx missing");
  return c;
}
