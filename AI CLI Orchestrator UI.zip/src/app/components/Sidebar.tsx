import { useState, useRef, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "motion/react";
import {
  Check,
  ChevronDown,
  Eye,
  EyeOff,
  Key,
  KeyRound,
  Menu,
  Plug,
  Search,
  Settings,
  Sparkles,
  Terminal,
  ShieldCheck,
  Globe2,
  UserCircle2,
  Mail,
} from "lucide-react";
import { OrchestratorLogo } from "./OrchestratorLogo";

type Status = "online" | "offline" | "limited";
type AuthMethod = "api_key" | "oauth" | "ssh" | "bearer" | "account";

export type Provider = {
  id: string;
  name: string;
  glyph: string;
  color: string;
  status: Status;
  authMethod: AuthMethod;
  authMethods: AuthMethod[];
  model: string;
  models: string[];
  endpoint?: string;
};

const AUTH_LABELS: Record<AuthMethod, { label: string; icon: typeof Key }> = {
  api_key: { label: "API Key", icon: Key },
  oauth: { label: "OAuth", icon: ShieldCheck },
  ssh: { label: "SSH Key", icon: Terminal },
  bearer: { label: "Bearer Token", icon: KeyRound },
  account: { label: "Account", icon: UserCircle2 },
};

const PROVIDERS: Provider[] = [
  {
    id: "claude",
    name: "Claude Code",
    glyph: "✻",
    color: "text-amber-500",
    status: "online",
    authMethod: "oauth",
    authMethods: ["oauth", "api_key", "ssh"],
    model: "claude-sonnet-4-6",
    models: ["claude-opus-4-7", "claude-sonnet-4-6", "claude-haiku-4-5"],
  },
  {
    id: "gemini",
    name: "Gemini CLI",
    glyph: "✦",
    color: "text-indigo-500",
    status: "online",
    authMethod: "api_key",
    authMethods: ["api_key", "oauth"],
    model: "gemini-3-pro",
    models: ["gemini-3-pro", "gemini-3-flash", "gemini-2.5-pro"],
  },
  {
    id: "codex",
    name: "Codex CLI",
    glyph: "◆",
    color: "text-emerald-500",
    status: "online",
    authMethod: "api_key",
    authMethods: ["api_key", "bearer"],
    model: "gpt-codex-mini",
    models: ["gpt-codex", "gpt-codex-mini", "o4-mini"],
  },
  {
    id: "copilot",
    name: "Copilot CLI",
    glyph: "❍",
    color: "text-zinc-500 dark:text-zinc-300",
    status: "online",
    authMethod: "oauth",
    authMethods: ["oauth", "ssh"],
    model: "copilot-chat",
    models: ["copilot-chat", "copilot-claude", "copilot-gpt5"],
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    glyph: "▲",
    color: "text-violet-500",
    status: "limited",
    authMethod: "api_key",
    authMethods: ["api_key", "bearer"],
    model: "deepseek-coder-v3",
    models: ["deepseek-coder-v3", "deepseek-chat-v3", "deepseek-r1"],
  },
  {
    id: "kimi",
    name: "Kimi Code",
    glyph: "✺",
    color: "text-rose-500",
    status: "online",
    authMethod: "api_key",
    authMethods: ["api_key", "bearer"],
    model: "kimi-k2",
    models: ["kimi-k2", "kimi-k1.5"],
  },
  {
    id: "cline",
    name: "Cline CLI",
    glyph: "◈",
    color: "text-cyan-500",
    status: "online",
    authMethod: "oauth",
    authMethods: ["oauth", "ssh", "api_key"],
    model: "cline-claude",
    models: ["cline-default", "cline-claude", "cline-gpt5"],
  },
  {
    id: "bob",
    name: "IBM BOB",
    glyph: "∎",
    color: "text-blue-500",
    status: "online",
    authMethod: "ssh",
    authMethods: ["ssh", "oauth", "bearer"],
    model: "granite-3.2-code",
    models: ["granite-3.2-code", "granite-3.1-code-base"],
    endpoint: "bob.ibmcloud.com:22",
  },
];

const STATUS_MAP: Record<Status, { dot: string; label: string; text: string }> = {
  online: { dot: "bg-emerald-500", label: "online", text: "text-emerald-600 dark:text-emerald-400" },
  offline: { dot: "bg-zinc-400", label: "offline", text: "text-zinc-500" },
  limited: { dot: "bg-rose-500", label: "rate-limited", text: "text-rose-600 dark:text-rose-400" },
};

export function Dropdown<T extends string>({
  value,
  options,
  labels,
  onChange,
  mono = true,
  className = "",
  listWidth,
}: {
  value: T;
  options: readonly T[];
  labels?: Record<string, string>;
  onChange: (v: T) => void;
  mono?: boolean;
  className?: string;
  listWidth?: string;
}) {
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const [rect, setRect] = useState<{ top: number; left: number; width: number } | null>(null);

  useLayoutEffect(() => {
    if (!open) return;
    const update = () => {
      const r = btnRef.current?.getBoundingClientRect();
      if (r) setRect({ top: r.bottom + 4, left: r.left, width: r.width });
    };
    update();
    window.addEventListener("scroll", update, true);
    window.addEventListener("resize", update);
    const onDown = (e: MouseEvent) => {
      if (btnRef.current && !btnRef.current.contains(e.target as Node)) {
        const menu = document.getElementById("dropdown-portal-menu");
        if (menu && menu.contains(e.target as Node)) return;
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => {
      window.removeEventListener("scroll", update, true);
      window.removeEventListener("resize", update);
      document.removeEventListener("mousedown", onDown);
    };
  }, [open]);

  return (
    <div className={`relative ${className}`}>
      <button
        ref={btnRef}
        onClick={() => setOpen((o) => !o)}
        className={`flex w-full items-center justify-between gap-2 rounded-md border border-zinc-200/70 bg-white/60 px-2.5 py-1.5 text-[11px] text-zinc-700 transition hover:bg-white dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-zinc-300 dark:hover:bg-white/[0.05] ${
          mono ? "font-mono" : ""
        }`}
      >
        <span className="truncate">{labels?.[value] ?? value}</span>
        <ChevronDown className={`h-3 w-3 shrink-0 text-zinc-400 transition ${open ? "rotate-180" : ""}`} />
      </button>
      {open && rect && typeof document !== "undefined" &&
        createPortal(
          <AnimatePresence>
            <motion.div
              id="dropdown-portal-menu"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              style={{ position: "fixed", top: rect.top, left: rect.left, width: rect.width }}
              className="z-[1000] max-h-[60vh] overflow-y-auto rounded-md border border-zinc-200 bg-white p-1 shadow-xl dark:border-white/10 dark:bg-zinc-950"
            >
              {options.map((o) => (
                <button
                  key={o}
                  onClick={() => {
                    onChange(o);
                    setOpen(false);
                  }}
                  className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-[11px] transition hover:bg-zinc-100 dark:hover:bg-white/5 ${
                    mono ? "font-mono" : ""
                  } ${o === value ? "text-indigo-600 dark:text-indigo-300" : "text-zinc-700 dark:text-zinc-300"}`}
                >
                  {labels?.[o] ?? o}
                  {o === value && <Check className="h-3 w-3" />}
                </button>
              ))}
            </motion.div>
          </AnimatePresence>,
          document.body
        )}
    </div>
  );
}

function ProviderCard({ p, onChange }: { p: Provider; onChange: (p: Provider) => void }) {
  const [show, setShow] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const s = STATUS_MAP[p.status];
  const AIcon = AUTH_LABELS[p.authMethod].icon;

  return (
    <div className="rounded-lg border border-zinc-200/70 bg-white/40 transition hover:border-zinc-300 dark:border-white/[0.06] dark:bg-white/[0.015] dark:hover:border-white/[0.14]">
      <button
        onClick={() => setExpanded((e) => !e)}
        className="flex w-full items-center gap-3 px-3 py-2.5 text-left"
      >
        <span className={`${p.color} font-mono text-[16px] leading-none`}>{p.glyph}</span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-[12.5px] text-zinc-900 dark:text-zinc-100">{p.name}</span>
          </div>
          <div className="mt-1 flex items-center gap-1.5">
            <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
            <span className={`font-mono text-[9px] uppercase tracking-wider ${s.text}`}>
              {s.label}
            </span>
            <span className="text-zinc-300 dark:text-zinc-700">·</span>
            <span className="font-mono text-[9px] text-zinc-500 dark:text-zinc-400">{p.model}</span>
          </div>
        </div>
        <ChevronDown
          className={`h-3.5 w-3.5 text-zinc-400 transition ${expanded ? "rotate-180" : ""}`}
        />
      </button>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="space-y-3 border-t border-zinc-200/70 px-3 py-3 dark:border-white/[0.05]">
              <div>
                <label className="mb-1 block font-mono text-[9px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                  Auth method
                </label>
                <Dropdown
                  value={p.authMethod}
                  options={p.authMethods}
                  labels={Object.fromEntries(
                    Object.entries(AUTH_LABELS).map(([k, v]) => [k, v.label])
                  )}
                  onChange={(v) => onChange({ ...p, authMethod: v })}
                  mono={false}
                />
              </div>

              <div>
                <label className="mb-1 flex items-center gap-1 font-mono text-[9px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                  <AIcon className="h-2.5 w-2.5" />
                  {AUTH_LABELS[p.authMethod].label}
                </label>
                {p.authMethod === "ssh" ? (
                  <div className="space-y-1">
                    <input
                      defaultValue={p.endpoint || "user@host:22"}
                      placeholder="user@host:port"
                      className="w-full rounded-md border border-zinc-200/70 bg-white px-2 py-1.5 font-mono text-[11px] text-zinc-800 outline-none placeholder:text-zinc-400 focus:border-indigo-400 dark:border-white/[0.07] dark:bg-black/30 dark:text-zinc-200"
                    />
                    <input
                      defaultValue="~/.ssh/id_ed25519"
                      placeholder="key path"
                      className="w-full rounded-md border border-zinc-200/70 bg-white px-2 py-1.5 font-mono text-[11px] text-zinc-800 outline-none placeholder:text-zinc-400 focus:border-indigo-400 dark:border-white/[0.07] dark:bg-black/30 dark:text-zinc-200"
                    />
                  </div>
                ) : p.authMethod === "oauth" ? (
                  <button className="flex w-full items-center justify-center gap-1.5 rounded-md border border-zinc-200/70 bg-white px-2 py-1.5 text-[11px] text-zinc-700 transition hover:bg-zinc-50 dark:border-white/[0.07] dark:bg-black/30 dark:text-zinc-200 dark:hover:bg-white/[0.04]">
                    <Globe2 className="h-3 w-3" />
                    Sign in with {p.name}
                  </button>
                ) : p.authMethod === "account" ? (
                  <div className="flex items-center gap-1 rounded-md border border-zinc-200/70 bg-white px-2 dark:border-white/[0.07] dark:bg-black/30">
                    <Mail className="h-3 w-3 text-zinc-400" />
                    <input
                      type="email"
                      defaultValue="you@gmail.com"
                      placeholder="account email"
                      className="w-full bg-transparent py-1.5 font-mono text-[11px] text-zinc-800 outline-none placeholder:text-zinc-400 dark:text-zinc-200"
                    />
                  </div>
                ) : (
                  <div className="flex items-center gap-1">
                    <input
                      type={show ? "text" : "password"}
                      defaultValue="sk-proj-••••••••••••••••3f9a"
                      className="flex-1 rounded-md border border-zinc-200/70 bg-white px-2 py-1.5 font-mono text-[11px] text-zinc-800 outline-none focus:border-indigo-400 dark:border-white/[0.07] dark:bg-black/30 dark:text-zinc-200"
                    />
                    <button
                      onClick={() => setShow((s) => !s)}
                      className="rounded-md border border-zinc-200/70 bg-white p-1.5 text-zinc-500 hover:bg-zinc-50 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-zinc-400 dark:hover:bg-white/[0.06]"
                    >
                      {show ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label className="mb-1 block font-mono text-[9px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                  Model
                </label>
                <Dropdown
                  value={p.model}
                  options={p.models}
                  onChange={(m) => onChange({ ...p, model: m })}
                />
              </div>

              <div className="flex items-center justify-between pt-0.5">
                <span className="font-mono text-[9px] text-zinc-500 dark:text-zinc-400">
                  verified · 4h ago
                </span>
                <button className="text-[10px] text-indigo-600 hover:text-indigo-500 dark:text-indigo-300">
                  Reconnect
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function Sidebar({ onOpenSettings }: { onOpenSettings?: () => void }) {
  const [providers, setProviders] = useState(PROVIDERS);
  const [q, setQ] = useState("");
  const [collapsed, setCollapsed] = useState(false);
  const [allOpen, setAllOpen] = useState(true);
  const [gitOpen, setGitOpen] = useState(true);

  const filtered = providers.filter((p) =>
    p.name.toLowerCase().includes(q.toLowerCase())
  );
  const online = providers.filter((p) => p.status === "online").length;

  if (collapsed) {
    return (
      <aside className="flex h-full w-[64px] shrink-0 flex-col items-center gap-2 border-r border-zinc-200/70 bg-zinc-50/40 py-3 backdrop-blur dark:border-white/[0.06] dark:bg-zinc-950/40">
        <OrchestratorLogo size={36} className="drop-shadow-[0_0_14px_rgba(139,92,246,0.45)]" />
        <button
          onClick={() => setCollapsed(false)}
          title="Expand sidebar"
          className="rounded-md border border-zinc-200/70 bg-white p-1.5 text-zinc-600 hover:bg-zinc-50 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-zinc-300 dark:hover:bg-white/[0.06]"
        >
          <Menu className="h-3.5 w-3.5" />
        </button>
        <div className="mt-2 flex flex-1 flex-col items-center gap-2 overflow-y-auto">
          {providers.map((p) => {
            const s = STATUS_MAP[p.status];
            return (
              <div
                key={p.id}
                title={`${p.name} · ${s.label}`}
                className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200/70 bg-white/60 dark:border-white/[0.07] dark:bg-white/[0.02]"
              >
                <span className={`${p.color} font-mono text-[15px] leading-none`}>{p.glyph}</span>
                <span
                  className={`absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full ring-2 ring-zinc-50 dark:ring-zinc-950 ${s.dot}`}
                />
              </div>
            );
          })}
        </div>
      </aside>
    );
  }

  return (
    <aside className="flex h-full w-[320px] shrink-0 flex-col border-r border-zinc-200/70 bg-zinc-50/40 backdrop-blur dark:border-white/[0.06] dark:bg-zinc-950/40">
      <div className="flex items-center gap-2.5 border-b border-zinc-200/70 px-4 py-4 dark:border-white/[0.06]">
        <OrchestratorLogo size={32} className="drop-shadow-[0_0_14px_rgba(139,92,246,0.5)]" />
        <span className="flex-1 bg-gradient-to-r from-indigo-400 via-violet-400 to-fuchsia-400 bg-clip-text text-[14px] leading-none tracking-tight text-transparent">
          Orchestrator
        </span>
        <button
          onClick={() => setCollapsed(true)}
          title="Collapse sidebar"
          className="rounded-md border border-zinc-200/70 bg-white p-1.5 text-zinc-500 hover:bg-zinc-50 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-zinc-400 dark:hover:bg-white/[0.06]"
        >
          <Menu className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="border-b border-zinc-200/70 px-3 py-3 dark:border-white/[0.06]">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.2em] text-zinc-500 dark:text-zinc-400">
            <Plug className="h-2.5 w-2.5" /> Providers
          </span>
          <span className="font-mono text-[10px] text-zinc-500 dark:text-zinc-400">
            <span className="text-emerald-600 dark:text-emerald-400">{online}</span>
            <span> / {providers.length}</span>
          </span>
        </div>
        <div className="mt-2.5 flex items-center gap-1.5 rounded-md border border-zinc-200/70 bg-white px-2 dark:border-white/[0.06] dark:bg-black/30">
          <Search className="h-3 w-3 text-zinc-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search providers"
            className="w-full bg-transparent py-1.5 text-[11.5px] text-zinc-800 outline-none placeholder:text-zinc-400 dark:text-zinc-200"
          />
        </div>
      </div>

      <div className="flex-1 space-y-2 overflow-y-auto px-3 py-3">
        <div className="overflow-hidden rounded-lg border border-zinc-200/70 bg-white/40 dark:border-white/[0.07] dark:bg-white/[0.015]">
          <button
            onClick={() => setAllOpen((o) => !o)}
            className="flex w-full items-center justify-between px-3 py-2.5"
          >
            <div className="flex items-center gap-2">
              <span className="bg-gradient-to-r from-indigo-400 to-fuchsia-400 bg-clip-text font-mono text-[10.5px] uppercase tracking-[0.22em] text-transparent">
                All CLIs
              </span>
              <span className="rounded-md border border-zinc-200/70 bg-white px-1.5 py-0.5 font-mono text-[9px] text-zinc-600 dark:border-white/[0.08] dark:bg-white/[0.04] dark:text-zinc-300">
                {filtered.length}
              </span>
            </div>
            <ChevronDown
              className={`h-3.5 w-3.5 text-zinc-400 transition ${allOpen ? "rotate-0" : "-rotate-90"}`}
            />
          </button>
          <AnimatePresence initial={false}>
            {allOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="space-y-1.5 border-t border-zinc-200/70 p-2 dark:border-white/[0.06]">
                  {filtered.map((p) => (
                    <ProviderCard
                      key={p.id}
                      p={p}
                      onChange={(np) =>
                        setProviders((prev) => prev.map((x) => (x.id === np.id ? np : x)))
                      }
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="overflow-hidden rounded-lg border border-zinc-200/70 bg-white/40 dark:border-white/[0.07] dark:bg-white/[0.015]">
          <button
            onClick={() => setGitOpen((o) => !o)}
            className="flex w-full items-center justify-between px-3 py-2.5"
          >
            <div className="flex items-center gap-2">
              <span className="bg-gradient-to-r from-indigo-400 to-fuchsia-400 bg-clip-text font-mono text-[10.5px] uppercase tracking-[0.22em] text-transparent">
                Git Handling
              </span>
              <span className="rounded-md border border-emerald-300/40 bg-emerald-50 px-1.5 py-0.5 font-mono text-[9px] text-emerald-700 dark:border-emerald-400/20 dark:bg-emerald-400/10 dark:text-emerald-300">
                clean
              </span>
            </div>
            <ChevronDown
              className={`h-3.5 w-3.5 text-zinc-400 transition ${gitOpen ? "rotate-0" : "-rotate-90"}`}
            />
          </button>
          <AnimatePresence initial={false}>
            {gitOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="space-y-2 border-t border-zinc-200/70 p-3 dark:border-white/[0.06]">
                  <GitField label="Branch" value="main" mono />
                  <GitField label="Status" value="3 files changed" valueClass="text-amber-600 dark:text-amber-300" />
                  <GitField label="User" value="Git Username" />
                  <GitField label="Repo" value="https://github.com/user/repo" mono truncate />

                  <div className="mt-2 flex items-center gap-1 rounded-md border border-zinc-200/70 bg-white px-2 dark:border-white/[0.07] dark:bg-black/40">
                    <span className="font-mono text-[11px] text-indigo-500">›</span>
                    <input
                      placeholder="git command... (commit, merge, etc.)"
                      className="flex-1 bg-transparent py-1.5 font-mono text-[10.5px] text-zinc-800 outline-none placeholder:text-zinc-400 dark:text-zinc-200"
                    />
                  </div>
                  <div className="flex items-start gap-1.5 rounded-md border border-indigo-300/40 bg-indigo-50/60 px-2 py-1.5 dark:border-indigo-400/20 dark:bg-indigo-400/[0.06]">
                    <Sparkles className="mt-0.5 h-2.5 w-2.5 shrink-0 text-indigo-500 dark:text-indigo-300" />
                    <span className="font-mono text-[9.5px] leading-snug text-indigo-700 dark:text-indigo-200">
                      Commands entered here are intercepted and handled by the Orchestrator.
                    </span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="border-t border-zinc-200/70 px-3 py-3 dark:border-white/[0.06]">
        <div className="rounded-lg border border-emerald-300/40 bg-emerald-50 px-3 py-2 dark:border-emerald-400/15 dark:bg-emerald-400/[0.04]">
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
            </span>
            <span className="text-[11px] text-zinc-900 dark:text-white">Backend healthy</span>
          </div>
          <div className="mt-1 font-mono text-[9px] text-zinc-500 dark:text-zinc-400">
            ws://127.0.0.1:8787 · 12ms
          </div>
        </div>
      </div>
    </aside>
  );
}

function GitField({
  label,
  value,
  mono,
  truncate,
  valueClass,
}: {
  label: string;
  value: string;
  mono?: boolean;
  truncate?: boolean;
  valueClass?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-12 shrink-0 font-mono text-[9px] uppercase tracking-[0.18em] text-zinc-500 dark:text-zinc-400">
        {label}
      </span>
      <span
        className={`flex-1 ${truncate ? "truncate" : ""} ${mono ? "font-mono" : ""} text-[11px] ${
          valueClass || "text-zinc-800 dark:text-zinc-200"
        }`}
      >
        {value}
      </span>
    </div>
  );
}
