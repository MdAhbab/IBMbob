import { useState } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Bell,
  Check,
  CircleAlert,
  Cpu,
  Eye,
  EyeOff,
  Folder,
  Info,
  Keyboard,
  Layers,
  Moon,
  Plug,
  Save,
  ShieldCheck,
  Sun,
  Trash2,
  Type,
} from "lucide-react";
import { useStore, type AuthMethod, type Provider } from "./store";
import { OrchestratorLogo } from "./OrchestratorLogo";
import { useTheme } from "./theme";

type Tab =
  | "general"
  | "providers"
  | "orchestrator"
  | "context"
  | "notifications"
  | "shortcuts"
  | "privacy"
  | "about";

const TABS: { id: Tab; label: string; icon: typeof Folder; desc: string }[] = [
  { id: "general", label: "General", icon: Folder, desc: "Workspace · appearance · font" },
  { id: "providers", label: "Providers", icon: Plug, desc: "All connected CLIs" },
  { id: "orchestrator", label: "Orchestrator", icon: Cpu, desc: "Model · routing · caps" },
  { id: "context", label: "Context", icon: Layers, desc: "Sync · auto-generated files" },
  { id: "notifications", label: "Notifications", icon: Bell, desc: "Sound · desktop alerts" },
  { id: "shortcuts", label: "Shortcuts", icon: Keyboard, desc: "Keyboard map" },
  { id: "privacy", label: "Privacy", icon: ShieldCheck, desc: "Telemetry · local data" },
  { id: "about", label: "About", icon: Info, desc: "Version · license · credits" },
];

export function Settings({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("general");

  return (
    <div className="h-full min-h-0 overflow-hidden">
      <div className="mx-auto flex h-full max-w-[1200px]">
        <aside className="w-[260px] shrink-0 border-r border-zinc-200/70 bg-white/40 px-3 py-5 backdrop-blur dark:border-white/[0.06] dark:bg-zinc-950/40">
          <button
            onClick={onClose}
            className="mb-5 flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] text-zinc-500 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-white/[0.05] dark:hover:text-zinc-200"
          >
            <ArrowLeft className="h-3 w-3" /> Back
          </button>
          <div className="px-2 font-mono text-[10px] uppercase tracking-[0.22em] text-zinc-500">
            Settings
          </div>
          <div className="mt-3 space-y-0.5">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition ${
                  tab === t.id
                    ? "bg-zinc-900 text-white dark:bg-white dark:text-zinc-900"
                    : "text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-white/[0.05]"
                }`}
              >
                <t.icon className="h-3.5 w-3.5" />
                <div className="flex-1 leading-tight">
                  <div className="text-[12.5px]">{t.label}</div>
                  <div
                    className={`text-[10px] ${
                      tab === t.id
                        ? "text-zinc-300 dark:text-zinc-500"
                        : "text-zinc-500"
                    }`}
                  >
                    {t.desc}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </aside>

        <div className="flex-1 overflow-y-auto px-8 py-7 scrollbar-thin">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.18 }}
          >
            {tab === "general" && <GeneralPanel />}
            {tab === "providers" && <ProvidersPanel />}
            {tab === "orchestrator" && <OrchestratorPanel />}
            {tab === "context" && <ContextPanel />}
            {tab === "notifications" && <NotificationsPanel />}
            {tab === "shortcuts" && <ShortcutsPanel />}
            {tab === "privacy" && <PrivacyPanel />}
            {tab === "about" && <AboutPanel />}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="mb-6">
      <h2 className="text-[22px] tracking-tight text-zinc-900 dark:text-white">{title}</h2>
      <p className="mt-1 text-[12.5px] text-zinc-500">{sub}</p>
    </div>
  );
}

function Row({
  title,
  desc,
  children,
}: {
  title: string;
  desc?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-6 border-b border-zinc-200/70 px-1 py-4 dark:border-white/[0.05]">
      <div className="min-w-0">
        <div className="text-[13px] text-zinc-900 dark:text-white">{title}</div>
        {desc && <div className="mt-0.5 text-[11.5px] text-zinc-500">{desc}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className={`relative h-5 w-9 rounded-full transition ${
        on ? "bg-indigo-500" : "bg-zinc-300 dark:bg-white/15"
      }`}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 600, damping: 35 }}
        className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow ${
          on ? "right-0.5" : "left-0.5"
        }`}
      />
    </button>
  );
}

function GeneralPanel() {
  const { workspace, setWorkspace, prefs, setPrefs } = useStore();
  const { theme, toggle } = useTheme();
  return (
    <>
      <SectionTitle title="General" sub="Workspace location, appearance, and typography." />

      <div className="rounded-xl border border-zinc-200/70 bg-white/60 px-4 dark:border-white/[0.06] dark:bg-zinc-950/40">
        <Row title="Workspace folder" desc={workspace?.path || "Not set"}>
          <button
            onClick={async () => {
              try {
                // @ts-ignore
                if (window.showDirectoryPicker) {
                  // @ts-ignore
                  const h = await window.showDirectoryPicker();
                  setWorkspace({ path: `~/${h.name}`, name: h.name });
                }
              } catch {}
            }}
            className="rounded-md border border-zinc-200/70 bg-white px-3 py-1.5 text-[11.5px] text-zinc-700 hover:bg-zinc-50 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-zinc-200 dark:hover:bg-white/[0.06]"
          >
            Change…
          </button>
        </Row>
        <Row title="Theme" desc="Dark, light, or system">
          <button
            onClick={toggle}
            className="flex items-center gap-1.5 rounded-md border border-zinc-200/70 bg-white px-3 py-1.5 text-[11.5px] text-zinc-700 hover:bg-zinc-50 dark:border-white/[0.07] dark:bg-white/[0.02] dark:text-zinc-200"
          >
            {theme === "dark" ? <Moon className="h-3 w-3" /> : <Sun className="h-3 w-3" />}
            {theme === "dark" ? "Dark" : "Light"}
          </button>
        </Row>
        <Row title="Font size" desc="Density of chat & terminal text">
          <div className="flex items-center gap-1">
            {(["sm", "md", "lg"] as const).map((s) => (
              <button
                key={s}
                onClick={() => setPrefs((p) => ({ ...p, fontSize: s }))}
                className={`rounded-md px-2 py-1 font-mono text-[10px] uppercase ${
                  prefs.fontSize === s
                    ? "bg-zinc-900 text-white dark:bg-white dark:text-zinc-900"
                    : "border border-zinc-200/70 bg-white text-zinc-600 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-300"
                }`}
              >
                <Type className="mr-1 inline h-2.5 w-2.5" />
                {s}
              </button>
            ))}
          </div>
        </Row>
        <Row title="Editor accent" desc="Used for primary buttons & highlights">
          <div className="flex items-center gap-1.5">
            {["#6366f1", "#10b981", "#f59e0b", "#f43f5e", "#a855f7"].map((c) => (
              <button
                key={c}
                className="h-5 w-5 rounded-full ring-2 ring-transparent transition hover:ring-zinc-300 dark:hover:ring-white/30"
                style={{ background: c }}
              />
            ))}
          </div>
        </Row>
      </div>
    </>
  );
}

function ProvidersPanel() {
  const { providers, setProviders } = useStore();
  return (
    <>
      <SectionTitle title="Providers" sub="Manage every CLI's credentials and default model." />
      <div className="space-y-2">
        {providers.map((p) => (
          <ProviderRow
            key={p.id}
            p={p}
            onChange={(np) =>
              setProviders((prev) => prev.map((x) => (x.id === p.id ? np : x)))
            }
          />
        ))}
      </div>
    </>
  );
}

function ProviderRow({ p, onChange }: { p: Provider; onChange: (p: Provider) => void }) {
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState(false);
  return (
    <div className="overflow-hidden rounded-xl border border-zinc-200/70 bg-white/60 dark:border-white/[0.06] dark:bg-zinc-950/40">
      <div
        role="button"
        tabIndex={0}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            setOpen((o) => !o);
          }
        }}
        className="flex w-full cursor-pointer items-center gap-3 px-4 py-3 text-left"
      >
        <span className={`${p.color} font-mono text-[18px] leading-none`}>{p.glyph}</span>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-[13px] text-zinc-900 dark:text-white">{p.name}</span>
            <span
              className={`rounded-md border px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider ${
                p.configured
                  ? "border-emerald-300/40 bg-emerald-50 text-emerald-700 dark:border-emerald-400/20 dark:bg-emerald-400/[0.08] dark:text-emerald-300"
                  : "border-amber-300/40 bg-amber-50 text-amber-700 dark:border-amber-400/20 dark:bg-amber-400/[0.08] dark:text-amber-300"
              }`}
            >
              {p.configured ? "configured" : "needs setup"}
            </span>
          </div>
          <div className="mt-0.5 font-mono text-[10.5px] text-zinc-500">
            {p.authMethod} · {p.model} · ${p.dailyCap}/day cap
          </div>
        </div>
        <div onClick={(e) => e.stopPropagation()}>
          <Toggle on={p.enabled} onChange={(v) => onChange({ ...p, enabled: v })} />
        </div>
      </div>
      {open && (
        <div className="space-y-3 border-t border-zinc-200/70 bg-zinc-50/40 px-4 py-4 dark:border-white/[0.05] dark:bg-black/30">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                Auth method
              </label>
              <select
                value={p.authMethod}
                onChange={(e) => onChange({ ...p, authMethod: e.target.value as AuthMethod })}
                className={inp}
              >
                {p.authMethods.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                Model
              </label>
              <select
                value={p.model}
                onChange={(e) => onChange({ ...p, model: e.target.value })}
                className={inp}
              >
                {p.models.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </div>
          </div>
          {p.authMethod === "ssh" ? (
            <div>
              <label className="mb-1 block font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                Host
              </label>
              <input
                defaultValue={p.endpoint}
                onBlur={(e) => onChange({ ...p, endpoint: e.target.value })}
                className={inp + " font-mono"}
              />
            </div>
          ) : p.authMethod !== "oauth" ? (
            <div>
              <label className="mb-1 block font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                Secret
              </label>
              <div className="flex items-center gap-1">
                <input
                  type={show ? "text" : "password"}
                  defaultValue="sk-proj-••••••••••••••••3f9a"
                  className={inp + " font-mono"}
                />
                <button
                  onClick={() => setShow((s) => !s)}
                  className="rounded-md border border-zinc-200/70 bg-white p-2 text-zinc-500 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-300"
                >
                  {show ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>
          ) : (
            <button className="w-full rounded-lg border border-zinc-200/70 bg-white py-2 text-[12px] text-zinc-700 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-200">
              Reconnect with OAuth
            </button>
          )}
          <div>
            <label className="mb-1 block font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-500">
              Daily cap (USD)
            </label>
            <input
              type="number"
              value={p.dailyCap}
              onChange={(e) => onChange({ ...p, dailyCap: Number(e.target.value) || 0 })}
              className={inp + " font-mono"}
            />
          </div>
          <div className="flex justify-end gap-2">
            <button className="flex items-center gap-1 rounded-md border border-rose-300/40 bg-rose-50 px-2 py-1 text-[11px] text-rose-700 hover:bg-rose-100 dark:border-rose-400/20 dark:bg-rose-400/[0.08] dark:text-rose-300">
              <Trash2 className="h-3 w-3" /> Revoke
            </button>
            <button className="flex items-center gap-1 rounded-md bg-zinc-900 px-2 py-1 text-[11px] text-white dark:bg-white dark:text-zinc-900">
              <Save className="h-3 w-3" /> Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function OrchestratorPanel() {
  const { orchestrator, setOrchestrator } = useStore();
  return (
    <>
      <SectionTitle title="Orchestrator" sub="The IBM Cloud agent that divides tasks across your CLIs." />
      <div className="rounded-xl border border-zinc-200/70 bg-white/60 px-4 dark:border-white/[0.06] dark:bg-zinc-950/40">
        <Row title="Orchestrator model" desc="Custom agent built on IBM Granite via IBM Cloud">
          <select
            value={orchestrator.model}
            onChange={(e) => setOrchestrator((o) => ({ ...o, model: e.target.value }))}
            className={inp + " font-mono w-[220px]"}
          >
            <option value="granite-3.2-instruct">granite-3.2-instruct</option>
            <option value="granite-3.2-code">granite-3.2-code</option>
            <option value="granite-3.1-instruct">granite-3.1-instruct</option>
          </select>
        </Row>
        <Row title="Routing strategy" desc="How subtasks are matched to CLIs">
          <select
            value={orchestrator.routingStrategy}
            onChange={(e) =>
              setOrchestrator((o) => ({ ...o, routingStrategy: e.target.value as any }))
            }
            className={inp + " w-[220px]"}
          >
            <option value="specialty">Specialty-based (recommended)</option>
            <option value="round_robin">Round-robin</option>
            <option value="cheapest">Cheapest first</option>
            <option value="fastest">Fastest p95</option>
          </select>
        </Row>
        <Row title="Max parallelism" desc="Concurrent agents allowed">
          <input
            type="number"
            min={1}
            max={12}
            value={orchestrator.parallelism}
            onChange={(e) =>
              setOrchestrator((o) => ({ ...o, parallelism: Number(e.target.value) || 1 }))
            }
            className={inp + " w-[100px] font-mono"}
          />
        </Row>
        <Row title="Auto failover" desc="Re-route automatically before a CLI hits its wall">
          <Toggle
            on={orchestrator.autoFailover}
            onChange={(v) => setOrchestrator((o) => ({ ...o, autoFailover: v }))}
          />
        </Row>
        <Row title="Global daily cap" desc="USD across every CLI per day">
          <input
            type="number"
            value={orchestrator.globalDailyCap}
            onChange={(e) =>
              setOrchestrator((o) => ({ ...o, globalDailyCap: Number(e.target.value) || 0 }))
            }
            className={inp + " w-[100px] font-mono"}
          />
        </Row>
      </div>
    </>
  );
}

function ContextPanel() {
  const { prefs, setPrefs } = useStore();
  return (
    <>
      <SectionTitle title="Context" sub="How the workspace context bus behaves." />
      <div className="rounded-xl border border-zinc-200/70 bg-white/60 px-4 dark:border-white/[0.06] dark:bg-zinc-950/40">
        <Row title="Auto-sync context" desc="Push changes to every agent within 2s">
          <Toggle
            on={prefs.autoSync}
            onChange={(v) => setPrefs((p) => ({ ...p, autoSync: v }))}
          />
        </Row>
        <Row title="Auto-generated files" desc="Let the orchestrator write divisions.md & task-graph.md">
          <Toggle on={true} onChange={() => {}} />
        </Row>
        <Row title="Max context size" desc="Per-agent context window (KB)">
          <input
            type="number"
            defaultValue={128}
            className={inp + " w-[100px] font-mono"}
          />
        </Row>
        <Row title="Excluded files" desc="Globs that never leave the local machine">
          <input
            defaultValue=".env, *.pem, secrets/**"
            className={inp + " w-[260px] font-mono"}
          />
        </Row>
      </div>
    </>
  );
}

function NotificationsPanel() {
  const { prefs, setPrefs } = useStore();
  return (
    <>
      <SectionTitle title="Notifications" sub="Stay in flow without losing alerts." />
      <div className="rounded-xl border border-zinc-200/70 bg-white/60 px-4 dark:border-white/[0.06] dark:bg-zinc-950/40">
        <Row title="Sound alerts" desc="Chime when a task completes or needs approval">
          <Toggle on={prefs.sound} onChange={(v) => setPrefs((p) => ({ ...p, sound: v }))} />
        </Row>
        <Row title="Desktop notifications" desc="OS-level toasts for permission requests">
          <Toggle
            on={prefs.desktopNotifs}
            onChange={(v) => setPrefs((p) => ({ ...p, desktopNotifs: v }))}
          />
        </Row>
        <Row title="Rate-limit warnings" desc="Notify at 85% quota burn">
          <Toggle on={true} onChange={() => {}} />
        </Row>
      </div>
    </>
  );
}

const KEYS: { combo: string; action: string }[] = [
  { combo: "⌘ K", action: "Open command palette" },
  { combo: "⌘ ⇧ P", action: "Toggle Processes view" },
  { combo: "⌘ ,", action: "Open settings" },
  { combo: "⌘ /", action: "Focus chat input" },
  { combo: "⌘ ⇧ V", action: "Voice dictation" },
  { combo: "⌘ ⇧ N", action: "New session" },
  { combo: "⌘ Enter", action: "Dispatch to orchestrator" },
  { combo: "Esc", action: "Cancel current job" },
];

function ShortcutsPanel() {
  return (
    <>
      <SectionTitle title="Keyboard shortcuts" sub="Move faster. Configurable bindings coming soon." />
      <div className="overflow-hidden rounded-xl border border-zinc-200/70 bg-white/60 dark:border-white/[0.06] dark:bg-zinc-950/40">
        {KEYS.map((k, i) => (
          <div
            key={k.combo}
            className={`flex items-center justify-between px-4 py-3 ${
              i !== KEYS.length - 1 ? "border-b border-zinc-200/70 dark:border-white/[0.05]" : ""
            }`}
          >
            <span className="text-[12.5px] text-zinc-800 dark:text-zinc-200">{k.action}</span>
            <kbd className="rounded-md border border-zinc-200/70 bg-zinc-50 px-2 py-0.5 font-mono text-[10.5px] text-zinc-700 dark:border-white/[0.07] dark:bg-white/[0.04] dark:text-zinc-200">
              {k.combo}
            </kbd>
          </div>
        ))}
      </div>
    </>
  );
}

function PrivacyPanel() {
  const { reset } = useStore();
  return (
    <>
      <SectionTitle title="Privacy" sub="Orchestra runs entirely on your machine." />
      <div className="rounded-xl border border-zinc-200/70 bg-white/60 px-4 dark:border-white/[0.06] dark:bg-zinc-950/40">
        <Row title="Telemetry" desc="We never collect any usage data">
          <span className="inline-flex items-center gap-1 rounded-md border border-emerald-300/40 bg-emerald-50 px-1.5 py-0.5 font-mono text-[10px] text-emerald-700 dark:border-emerald-400/20 dark:bg-emerald-400/[0.08] dark:text-emerald-300">
            <Check className="h-2.5 w-2.5" /> Disabled by design
          </span>
        </Row>
        <Row title="Credential storage" desc="OS keychain (Keychain / Credential Vault / libsecret)">
          <span className="font-mono text-[10.5px] text-zinc-500">os keychain</span>
        </Row>
        <Row title="Session storage" desc="YAML files inside your workspace folder">
          <span className="font-mono text-[10.5px] text-zinc-500">.orchestra/sessions/</span>
        </Row>
        <Row title="Reset everything" desc="Wipe local state and walk through onboarding again">
          <button
            onClick={() => {
              if (confirm("Reset orchestra to defaults? This will re-run onboarding.")) reset();
            }}
            className="flex items-center gap-1 rounded-md border border-rose-300/40 bg-rose-50 px-2.5 py-1.5 text-[11.5px] text-rose-700 hover:bg-rose-100 dark:border-rose-400/20 dark:bg-rose-400/[0.08] dark:text-rose-300"
          >
            <CircleAlert className="h-3 w-3" /> Reset
          </button>
        </Row>
      </div>
    </>
  );
}

function AboutPanel() {
  return (
    <>
      <SectionTitle title="About" sub="Orchestrator · the local conductor for AI coding agents." />
      <div className="rounded-2xl border border-zinc-200/70 bg-gradient-to-br from-indigo-50 to-white px-6 py-6 dark:border-white/[0.06] dark:from-indigo-500/[0.06] dark:to-zinc-950/40">
        <div className="flex items-center gap-3">
          <OrchestratorLogo size={40} className="drop-shadow-[0_0_18px_rgba(139,92,246,0.55)]" />
          <div>
            <div className="bg-gradient-to-r from-indigo-400 via-violet-400 to-fuchsia-400 bg-clip-text text-[15px] tracking-tight text-transparent">
              Orchestrator
            </div>
            <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-zinc-500">
              v1.0.0-beta · commit 9c8b3a2
            </div>
          </div>
        </div>
        <p className="mt-4 max-w-md text-[12.5px] leading-relaxed text-zinc-600 dark:text-zinc-300">
          MIT licensed. Built with React, Tailwind, and a tiny IBM-Cloud-powered routing agent
          that orchestrates Claude, Gemini, Codex, Copilot, DeepSeek, Kimi, Cline, and BOB.
        </p>
        <div className="mt-4 flex gap-2">
          <a className="rounded-md border border-zinc-200/70 bg-white px-2.5 py-1 text-[11px] text-zinc-700 hover:bg-zinc-50 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-200">
            Docs
          </a>
          <a className="rounded-md border border-zinc-200/70 bg-white px-2.5 py-1 text-[11px] text-zinc-700 hover:bg-zinc-50 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-200">
            GitHub
          </a>
          <a className="rounded-md border border-zinc-200/70 bg-white px-2.5 py-1 text-[11px] text-zinc-700 hover:bg-zinc-50 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-200">
            Changelog
          </a>
        </div>
      </div>
    </>
  );
}

const inp =
  "rounded-md border border-zinc-200/70 bg-white px-2 py-1.5 text-[12px] text-zinc-800 outline-none focus:border-indigo-400 dark:border-white/[0.06] dark:bg-white/[0.02] dark:text-zinc-200";
